﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GameDirector : MonoBehaviour {
	GameObject hpGage;
	float c=0;
	// Use this for initialization
	void Start () {
		this.hpGage = GameObject.Find ("hpGage");
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	public void DecreaseHp(){
		this.hpGage.GetComponent<Image> ().fillAmount -= 0.1f;
		c++;
		print (c);
		if (c == 10) {
			SceneManager.LoadScene ("GameScene");
		}
	}
}
